package com.example.domain.exercise.swipeservice.kafka;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;

@Slf4j
public class SwipeRecordConsumer {
  @Autowired private KafkaTemplate<String, String> kafkaTemplate;

  @KafkaListener(topics = "swipeRecord-topic", groupId = "group_id")
  public void consume(String msg) {
    log.info("consume message: " + msg);
  }
}
