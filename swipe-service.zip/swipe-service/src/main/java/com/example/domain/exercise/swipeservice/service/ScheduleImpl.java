// package com.example.domain.exercise.swipeservice.service;
//
// import org.springframework.scheduling.annotation.Scheduled;
// import org.springframework.stereotype.Service;
//
// import java.time.LocalDateTime;
//
// @Service
// public class ScheduleImpl {
//
//  @Scheduled(cron = "*/10 * * * * *")
//  public void Display() {
//    LocalDateTime dt = LocalDateTime.now();
//    System.out.println("Hey!!" + dt);
//  }
// }
