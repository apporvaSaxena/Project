package com.example.domain.exercise.swipeservice.constants;

public class AppConstants {

  public static final String DATE_FORMAT = "yyyy-MM-dd";
}
