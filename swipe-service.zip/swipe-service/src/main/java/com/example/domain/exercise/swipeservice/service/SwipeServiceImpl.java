package com.example.domain.exercise.swipeservice.service;

import com.example.domain.exercise.swipeservice.models.EmployeeSwipeRequest;
import com.example.domain.exercise.swipeservice.repository.SwipeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@Service
public class SwipeServiceImpl implements SwipeService {

  private static final Logger LOG = LoggerFactory.getLogger(SwipeServiceImpl.class);

  @Autowired private SwipeRepository swipeRepository;

  //  public SwipeServiceImpl(SwipeRepository swipeRepository) {
  //    this.swipeRepository = swipeRepository;
  //  }

  //  @Autowired private SwipeRecordProducer swipeRecordProducer;

  //  @Autowired private ObjectMapper mapper;

  //  @Autowired private EmployeeProfileServiceCaller employeeProfileServiceCaller;

  @Override
  public EmployeeSwipeRequest saveSwipeRecord(EmployeeSwipeRequest employeeSwipeRequest) {
    if (Objects.isNull(employeeSwipeRequest.getSwipeTime())) {
      employeeSwipeRequest.setSwipeTime(LocalDateTime.now());
    }
    return swipeRepository.save(employeeSwipeRequest);
  }

  // List Of Employees(date)
  public List<EmployeeSwipeRequest> findDistinctEmployeeIds() {
    return swipeRepository.findDistinctEmployeeIdBySwipeTime(
        LocalDateTime.of(2023, 4, 19, 00, 00, 00));
  }
  // swipeInFirst(empId, date)

  // swipeOutLast(empId)

  //  // @Scheduled(cron = "${cron.user.status.publish}")
  //  public void calculateEmployeesTotalOfficeHourAndPublishToKafkaTopic() {
  //    LOG.info("Calculating employees Total office hours for the day.");
  //    getSwipesForDay().stream()
  //        .collect(Collectors.groupingBy(EmployeeSwipeRequest::getEmployeeId))
  //        .entrySet()
  //        .stream()
  //        .forEach(
  //            entry -> {
  //              List<SwipeInfo> swipes = entry.getValue();
  //              if (Objects.nonNull(swipes) && swipes.size() > 0) {
  //                Long employeeId = entry.getKey();
  //                Integer totalInOfficeHour = calculateInOfficeHourForUser(employeeId, swipes);
  //                EmployeeStateDetails employeeStateInfo =
  //                    new EmployeeStateDetails(employeeId, LocalDate.now());
  //                employeeStateInfo.setTotalInOfficeHour(totalInOfficeHour);
  //                AttendanceState overAllState = determineUserStatus(totalInOfficeHour);
  //                employeeStateInfo.setEmployeeState(overAllState);
  //                publishToKafkaTopic(employeeStateInfo);
  //              }
  //            });
  //  }
  //
  //  private Integer calculateInOfficeHourForUser(Long employeeId, List<SwipeInfo> swips) {
  //    LocalTime totalHours = LocalTime.of(0, 0, 0);
  //    for (SwipeInfo swipe : swips) {
  //      // To handle the situation if employee is still in the office we are calculating
  //      // inOfficeHours.
  //      if (Objects.isNull(swipe.getSwipeOutTime())) {
  //        swipe.setSwipeOutTime(LocalDateTime.now());
  //      }
  //      long minutesBetween =
  //          ChronoUnit.MINUTES.between(swipe.getSwipeInTime(), swipe.getSwipeOutTime());
  //      totalHours = totalHours.plus(minutesBetween, ChronoUnit.MINUTES);
  //    }
  //    return totalHours.getHour();
  //  }
  //
  //  public List<EmployeeSwipeRequest> getSwipesForDay() {
  //    return swipeRepository.findSwipesForToday(getCurrentDateAsString());
  //  }
  //
  //  private String getCurrentDateAsString() {
  //    return LocalDate.now().format(DateTimeFormatter.ofPattern(AppConstants.DATE_FORMAT));
  //  }
  //
  //  private AttendanceState determineUserStatus(Integer inOfficeHour) {
  //    return inOfficeHour < 4
  //        ? AttendanceState.ABSENT
  //        : ((inOfficeHour >= 4 && inOfficeHour < 8)
  //            ? AttendanceState.HALF_DAY
  //            : AttendanceState.PRESENT);
  //  }
  //
  //  private void publishToKafkaTopic(EmployeeStateDetails userStatusInfo) {
  //    LOG.info(userStatusInfo.toString());
  //    try {
  //      String jsonString = mapper.writeValueAsString(userStatusInfo);
  //      attendanceProducer.sendMessage(jsonString);
  //    } catch (JsonProcessingException e) {
  //      LOG.error("Could not publish record: " + userStatusInfo);
  //    }
  //  }
}
