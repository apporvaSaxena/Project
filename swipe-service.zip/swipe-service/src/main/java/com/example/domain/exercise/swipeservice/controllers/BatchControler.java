package com.example.domain.exercise.swipeservice.controllers;

import com.example.domain.exercise.swipeservice.service.ScheduleImpl;
import org.springframework.beans.factory.annotation.Autowired;

public class BatchControler {
  @Autowired ScheduleImpl scheduleImpl;

  public String Schedule() {
    scheduleImpl.Display();
    return "SUCCESS";
  }
}
