package com.example.domain.exercise.swipeservice.service;

import com.example.domain.exercise.swipeservice.models.EmployeeSwipeRequest;

public interface SwipeService {
  public EmployeeSwipeRequest saveSwipeRecord(EmployeeSwipeRequest employeeSwipeRequest);
  //	public List<SwipeInfo> getSwipesByEmployeeId(Long userId);
  //	public List<SwipeInfo> getSwipesForTodayByEmployeeId(Long userId);
  //	public List<SwipeInfo> getSwipesForDay();
  //	public void calculateInOfficeHourAndPublishEmployeeStateToKafkaTopic();
}
