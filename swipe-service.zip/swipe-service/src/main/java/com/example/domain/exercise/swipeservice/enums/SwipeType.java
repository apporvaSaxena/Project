package com.example.domain.exercise.swipeservice.enums;

public enum SwipeType {
  SWIPE_IN,
  SWIPE_OUT
}
