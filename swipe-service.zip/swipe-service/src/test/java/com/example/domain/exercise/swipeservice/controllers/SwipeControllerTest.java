package com.example.domain.exercise.swipeservice.controllers;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class SwipeControllerTest {

  private SwipeController swipeController;

  //  @Test
  //  void givenUserSwipeIn_thenCreateRecord() {
  //    Long employeeId = Long.valueOf(123);
  //    var actualRequest = swipeController.swipeIn(employeeId);
  //    Assertions.assertEquals("in", actualRequest.getSwipeStatus());
  //  }
  //
  //  @Test
  //  void givenUserSwipeOut_thenCreateRecord() {
  //    Long employeeId = Long.valueOf(123);
  //    var actualRequest = swipeController.swipeIn(employeeId);
  //    Assertions.assertEquals("out", actualRequest.getSwipeStatus());
  //  }
}
